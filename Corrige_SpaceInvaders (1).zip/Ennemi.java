import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;

public class Ennemi {
	private double x,y;
	//private Color c;
	private Image image;
	
	
	public Ennemi(double x,double y,Image image) {
		if(x>=0&&x<610&&y>=0&&y<450) {
			this.x = x;
			this.y = y;
		}else {
			this.x = 0;
			this.y = 0;
		}
		
		this.image = image;
	}
	
	public void dessiner(Graphics g) {
		//g.setColor(c);
		//g.fillRect((float)x, (float)y, 30, 30);
		
		g.drawImage(image,(float)x,(float)y);
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		if(x>=0&&x<640)
			this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		if(y>=0&&y<640)
			this.y = y;
	}
	

	
}
