import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

public class Projectile {
	private float x, y;
	private int vy;
	private Image image;

	public Projectile(int x, int y, int vy) throws SlickException {
		if (x >= 0 && y >= 0 && x < 640 && y < 480) {
			this.x = x;
			this.y = y;
			this.vy = vy;
		}
		else
		{
			this.x = 0;
			this.y = 0;
			this.vy = 0;
		}
		
		image = new Image("images/feu.png");
	}

	public void dessiner(Graphics g) {
		//g.setColor(Color.white);
		//g.fillOval(x-3, y-3, 6, 6);
		
		g.drawImage(image, x-4, y-4);
	}
	
	public void deplacer(int delta) {
		// vitesse = distance / temps
		float distance = vy * delta/1000f;
		y = y + distance;
	}
	
	public boolean horsEcran() {
		if(y<=0)
			return true;
		else
			return false;
	}
	
	public boolean testCollision(Ennemi e) {
		if(this.x >= e.getX() && this.x <= e.getX()+30 && this.y >= e.getY() && this.y <= e.getY()+30)
			return true;
		else 
			return false;
	}
}
