
import java.util.ArrayList;

import org.newdawn.slick.BasicGame;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;

public class SpaceInvaders extends BasicGame {

	private Ennemi[][] e = new Ennemi[10][6];
	private Vaisseau v;
	private ArrayList<Projectile> p = new ArrayList<Projectile>();
	private Image fond;
	
	public SpaceInvaders(String title) {
		super(title);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void render(GameContainer gc, Graphics g) throws SlickException {
		g.drawImage(fond, 0, 0);
		for(int i = 0; i<10; i++) {
			for(int j=0;j<6;j++) {
				if(e[i][j]!=null)
					e[i][j].dessiner(g);
			}
		}
		
		v.dessiner(g);
		
		for(int i=0;i<p.size();i++) {
			Projectile proj = p.get(i);
			proj.dessiner(g);
		}
		
	}

	@Override
	public void init(GameContainer gc) throws SlickException {
		fond = new Image("images/fond.jpg");
		for(int i = 0; i<10; i++) {
			for(int j=0;j<6;j++) {
				double x = 155 + 33*i;
				double y = 50 + 33*j;
				
				//Color[] couleurs = {Color.red,Color.orange,Color.yellow,Color.green,Color.pink,Color.blue};
				//Color c = couleurs[j];
				//e[i][j] = new Ennemi(x,y,c);
				
				Image[] images = {new Image("images/nuage.png"),new Image("images/mario.png"),new Image("images/fleur.png"),
						new Image("images/goomba.png"),new Image("images/champi.png"),new Image("images/bloc.png")};
				Image image = images[j];
				e[i][j] = new Ennemi(x,y,image);
			}
		}
		
		v = new Vaisseau();
	}

	@Override
	public void update(GameContainer gc, int delta) throws SlickException {
		Input input = gc.getInput();
		
		if(input.isKeyPressed(Input.KEY_LEFT)) {
			v.gauche();
		}
		if(input.isKeyPressed(Input.KEY_RIGHT)) {
			v.droite();
		}
		for(int i=0;i<p.size();i++) {
			p.get(i).deplacer(delta);
		}
		
		for(int i=0;i<p.size();i++) {
			if(p.get(i).horsEcran()) {
				p.remove(i);
				i--;
			}
		}
		
		for(int i =0; i<10;i++) {
			for(int j=0;j<6;j++) {
				for(int k=0;k<p.size();k++) {
					if(e[i][j]!=null&& p.get(k).testCollision(e[i][j])) {
						e[i][j]=null;
						p.remove(k);
						k--;
					}
				}
			}
		}
		
		if(input.isKeyPressed(Input.KEY_SPACE)&&p.size()<5) {
			p.add(new Projectile(v.getX(),v.getY(),-250));
		}
	}

}
