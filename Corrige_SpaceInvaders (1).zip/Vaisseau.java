import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.SlickException;

public class Vaisseau {
	private int x,y;
	private Image image;
	
	public Vaisseau() throws SlickException {
		x = 340;
		y = 383;
		image = new Image("images/bowser.png");
	}
	
	public void dessiner(Graphics g) {
		//g.setColor(Color.white);
		//g.fillOval(x-25, y-10, 50, 25);
		
		g.drawImage(image, x-10, y-25);
	}
	
	public void gauche() {
		if(x-10-25>=0)
			x-=10;
	}
	
	public void droite() {
		if(x+10+25<640)
			x+=10;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	
}
